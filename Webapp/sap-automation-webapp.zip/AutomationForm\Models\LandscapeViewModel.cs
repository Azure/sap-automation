﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomationForm.Models
{
    public class LandscapeViewModel
    {
        public ParameterGroupingModel[] ParameterGroupings { get; set; }
        public LandscapeModel Landscape { get; set; }
    }
}
