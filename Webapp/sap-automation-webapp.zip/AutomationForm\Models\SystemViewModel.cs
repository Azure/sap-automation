﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomationForm.Models
{
    public class SystemViewModel
    {
        public ParameterGroupingModel[] ParameterGroupings { get; set; }
        public SystemModel System { get; set; }
    }
}
